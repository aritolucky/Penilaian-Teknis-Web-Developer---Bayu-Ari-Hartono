-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 17, 2023 at 09:59 AM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `biznet`
--

-- --------------------------------------------------------

--
-- Table structure for table `assessments`
--

CREATE TABLE `assessments` (
  `id` int NOT NULL,
  `date` datetime DEFAULT NULL,
  `username` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `score` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `assessments`
--

INSERT INTO `assessments` (`id`, `date`, `username`, `score`) VALUES
(1, '2011-01-01 09:00:00', 'john', 85.5),
(2, '2011-01-15 14:30:00', 'jane', 90.2),
(3, '2011-02-10 11:45:00', 'bob', 75.8),
(4, '2011-03-01 08:15:00', 'alice', 92.3),
(5, '2011-03-20 13:00:00', 'nguyen', 88.1),
(6, '2011-04-30 10:30:00', 'brown', 79.6),
(7, '2011-05-02 12:45:00', 'lee', 91),
(8, '2011-05-20 09:15:00', 'chen', 83.7),
(9, '2011-06-10 15:00:00', 'wang', 87.2),
(10, '2011-07-05 11:30:00', 'kim', 94.5),
(11, '2011-07-20 14:45:00', 'kevin', 81.9),
(12, '2011-08-10 10:00:00', 'emily', 89.8),
(13, '2011-09-01 13:15:00', 'jason', 78.4),
(14, '2011-09-20 08:45:00', 'grace', 95.1),
(15, '2011-10-10 11:00:00', 'philip', 82.6),
(16, '2011-11-05 14:30:00', 'lisa', 90.7),
(17, '2011-11-20 09:15:00', 'steven', 86.3),
(18, '2011-12-10 12:00:00', 'cindy', 91.8);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assessments`
--
ALTER TABLE `assessments`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assessments`
--
ALTER TABLE `assessments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

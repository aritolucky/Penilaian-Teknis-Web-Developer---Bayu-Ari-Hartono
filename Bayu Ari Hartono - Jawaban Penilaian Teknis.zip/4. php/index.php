<?php 

function generateBarcode($text, $type) {
    require_once('php-barcode.php');
    
    if ($type == 'qr') {
        $barcodeType = 'qrcode';
    } else {
        $barcodeType = 'code128';
    }
    
    $barcode = new Barcode($text, $barcodeType);
    $barcode->draw();
    
    header('Content-Type: image/png');
    imagepng($barcode->get_im());
}

generateBarcode('123456789', 'code'); 
generateBarcode('https://www.example.com', 'qr'); 


?>

